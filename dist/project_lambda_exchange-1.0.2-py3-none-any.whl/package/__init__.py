# /package/__init__.py
"""
Description for Package
"""

# from package.module import Example_class, method
from package.module import *
# from package import * 로 써도 된다.

__all__ = ['getApi']

# 패키지 버전 정의
__version__ = '1.0.2' 