def getApi(source):
    if source == "ping":
        return "pong"
    else:
        return "hm..."